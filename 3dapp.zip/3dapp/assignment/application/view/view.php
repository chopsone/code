<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
    <link rel="stylesheet" type='text/css' href="css/bootstrap-4.4.1.css">

    <!-- X3dom -->
    <link rel='stylesheet' type='text/css' href='css/x3dom.css'>

    <!-- Fontawesome CSS -->
    <link rel="stylesheet" type='text/css' href="css/all.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" type='text/css' href="css/custom.css">

    <!-- Link in some fonts — Not used because we finally installed the fonts
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> 
    -->

    <!-- Use a light box to view images in the gallery -->
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css">

    <title>Web 3D Applications Assignment</title>

  </head>
  <body id="bodyColor">
    <!-- HEADER -->
    <!-- Logo and navigation bar -->
    <nav id="headerColor" class="navbar sticky-top navbar-expand-sm navbar_museum">
      <div class="container-fluid">  
        <!-- Brand -->
        <!-- Title and tag line -->
        <div class="logo">
          <a id="headerTextColor" class="navbar-brand" href="index.php">
            <h1>The Museum of Instruments</h1>
            <p>Join us in celebrating music of the world</p>
          </a>
        </div>
                 
        <!-- Collapsible Navbar Menu Icon -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Link Menu item button to the links class navbar-collapse selector -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Links -->
          <ul class="navbar-nav ml-auto"> <!-- Use mx-auto to align centre, default to left or use mr-auto -->
            <!-- nothing changed from Lab 5 -->
            <li class="nav-item">
              <a id="navHome" href="#" class="nav-link active">Home</a>
            </li>
            <!-- Added navAbout ID, do we use this? -->
            <li class="nav-item">
              <a id="navAbout" href="#" class="nav-link">About</a>
            </li>
        
            <!-- Replace Dropdown from lab 5 with single nav lnk to models -->
            <li class="nav-item">
              <a id="navModels" href="#" class="nav-link" data-toggle="popover" data-trigger="hover" data-placement="bottom" title="X3D Models" data-content="There are six X3D models: Recorder, Bugle, Xylophone, Harmonica, Maracas and Cymbals.">Models</a>
            </li>
            <li class="nav-item">
              <a id="navContact" class="nav-link" href="#" data-toggle="modal" data-target="#contactModal">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- MAIN BODY -->
    <!-- Start 3D App SPA Contents -->
    <div class="container-fluid main_contents"> <!-- Start SPA Contents -->
      <!-- HOME PAGE block element (big picture and desc) -->
      <div id="home">
        <div class="row"> <!-- Main_3D Image or Carousel -->
          <div class ="col-sm-8">
            <div class="card">
              <div id="main_3d_image">
                <div id="main_text" class="col-xs-12 col-sm-5">
                  <div id="placeholder1">
                    <h2><?php echo $data[0][0]['title'] ?></h2>
                  </div>
                  <div id="placeholder2">
                    <h3><?php echo $data[0][0]['subTitle'] ?></h3>
                  </div>
                  <div id="placeholder3">
                    <p><?php echo $data[0][0]['picDescription'] ?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <!-- thumbnail that can be clicked -->
                  <div id="recorderImage">
                    <div id="overlayR">
                      <div id="title_l" class="card-title homeText">
                        <h2><?php echo $data[0][1]['title'] ?></h2>
                      </div>
                      <div id="subTitle_l" class="card-subtitle homeText">
                        <h3><?php echo $data[0][1]['subTitle'] ?></h3>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div id="bugleImage">
                    <div id="overlayB">
                      <div id="title_c" class="card-title homeText">
                        <h2><?php echo $data[0][2]['title'] ?></h2>
                      </div>
                      <div id="subTitle_c" class="card-subtitle homeText">
                        <h3><?php echo $data[0][2]['subTitle'] ?></h3>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Row of cards on the grid (descriptions of each instrument) -->
        <div class="row">
          <div class="col-sm-3">
            <div class="card">
              <div id="xylophoneImage">
                <div id="overlayX">
                  <div id="title_r" class="card-title homeText">
                    <h2><?php echo $data[0][3]['title'] ?></h2>
                  </div>
                  <div id="subTitle_r" class="card-subtitle homeText">
                    <h3><?php echo $data[0][3]['subTitle'] ?></h3>
                  </div> 
                </div>
              </div>  
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card">
              <div id="harmonicaImage">
                <div id="overlayH">
                  <div id="title_right22" class="card-title homeText">
                    <h2><?php echo $data[0][4]['title'] ?></h2>
                  </div>
                  <div id="subTitle_right22" class="card-subtitle homeText">
                    <h3><?php echo $data[0][4]['subTitle'] ?></h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card">
              <div id="maracasImage">
                <div id="overlayM">
                  <div id="title_11" class="card-title homeText">
                    <h2><?php echo $data[0][5]['title'] ?></h2>
                  </div>
                  <div id="subTitle_111" class="card-subtitle homeText">
                    <h3><?php echo $data[0][5]['subTitle'] ?></h3>
                  </div> 
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card">
              <div id="cymbalsImage">
                <div id="overlayC">
                  <div id="title_22" class="card-title homeText">
                    <h2><?php echo $data[0][6]['title'] ?></h2>
                  </div>
                  <div id="subTitle_22" class="card-subtitle homeText">
                    <h3><?php echo $data[0][6]['subTitle'] ?></h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End home page -->

      <!-- ABOUT PAGE block element -->
      <div id="about">
        <div id="recorderInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="recorderTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][1]['title'] ?></h2>
                </div>
                <div id="recorderSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][1]['subTitle'] ?></h3>
                </div>
                <div id="recorderDesc" class="aboutText card-text">
                  <p><?php echo $data[0][1]['picDescription'] ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="bugleInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="bugleTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][2]['title'] ?></h2>
                </div>
                <div id="bugleSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][2]['subTitle'] ?></h3>
                </div>
                <div id="bugleDesc" class="aboutText card-text">
                  <p><?php echo $data[0][2]['picDescription'] ?></p>
                </div>   
              </div>
            </div>
          </div>
        </div>
        <div id="xylophoneInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="xylophoneTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][3]['title'] ?></h2>
                </div>
                <div id="xylophoneSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][3]['subTitle'] ?></h3>
                </div>
                <div id="xylophoneDesc" class="aboutText card-text">
                  <p><?php echo $data[0][3]['picDescription'] ?></p>
                </div> 
              </div>
            </div>
          </div>
        </div>
        <div id="harmonicaInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="harmonicaTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][4]['title'] ?></h2>
                </div>
                <div id="harmonicaSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][4]['subTitle'] ?></h3>
                </div>
                <div id="harmonicaDesc" class="aboutText card-text">
                  <p><?php echo $data[0][4]['picDescription'] ?></p>
                </div> 
              </div>
            </div>
          </div>
        </div>
        <div id="maracasInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="maracasTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][5]['title'] ?></h2>
                </div>
                <div id="maracasSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][5]['subTitle'] ?></h3>
                </div>
                <div id="maracasDesc" class="aboutText card-text">
                  <p><?php echo $data[0][5]['picDescription'] ?></p>
                </div> 
              </div>
            </div>
          </div>
        </div>
        <div id="cymbalsInfo" class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="cymbalsTitle" class="aboutText card-title">
                  <h2><?php echo $data[0][6]['title'] ?></h2>
                </div>
                <div id="cymbalsSubTitle" class="aboutText card-subtitle">
                  <h3><?php echo $data[0][6]['subTitle'] ?></h3>
                </div>
                <div id="cymbalsDesc" class="aboutText card-text">
                  <p><?php echo $data[0][6]['picDescription'] ?></p>
                </div> 
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End home page -->

      <!-- MODELS PAGE -->
      <!-- Start X3D models and 3D Image Gallery -->
      <div id="models">
        <!-- Row to hold two cards to hold 1) the X3D model, and 2) the gallery-->
        <div class="row">
          <!-- Column for the camera view controls -->
          <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
            <div class="card text-left">
              <div id="cameraPanel">
                <div class="card-header">
                  <ul class="nav nav-tabs card-header-tabs">
                    <!-- Dropdown nav-tab -->
                    <li class="nav-item">
                      <a class="nav-link active" href="#" id="navCamControls">Cameras</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="navAnimControls" href="#">Animation</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#" id="navRendControls">Render</a>
                    </li>
                    <!-- Dropdown nav-tab -->
                    <li class="nav-item">
                      <a class="nav-link" href="#" id="navLightControls">Lights</a>
                    </li>
                  </ul>
                </div>
                <div class="modelModifiers">
                  <div class="card-body">
                    <div id="cameraControls">
                      <div class="card-Title x3dCamera_Subtitle modelText">
                        <h2>Camera Views</h2>
                      </div>    
                      <br>                        
                      <a id="cam_front" href="#" class="btn btn-primary btn-responsive" onclick="cameraFront();">Front</a>
                      <a id="cam_back" href="#" class="btn btn-secondary btn-responsive" onclick="cameraBack();">Back</a>
                      <a id="cam_left" href="#" class="btn btn-secondary btn-responsive" onclick="cameraLeft();">Left</a>
                      <a id="cam_right" href="#" class="btn btn-secondary btn-responsive" onclick="cameraRight();">Right</a>
                      <a id="cam_top" href="#" class="btn btn-secondary btn-responsive" onclick="cameraTop();">Top</a>
                      <a id="cam_bottom" href="#" class="btn btn-secondary btn-responsive" onclick="cameraBottom();">Bottom</a>
                      <div class="card-text x3dCameraDescription modelText">
                        <p>These buttons select a range of X3D model viewpoints. Each model is fitted with a front, back, left, right, top and bottom view.</p>
                      </div>
                    </div>
                    <div id="animationControls">
                      <div class="card-Title x3dAnimationSubtitle modelText">
                        <h2>Animation Options</h2>
                      </div>
                      <br>
                      <a href="#" class="btn btn-outline-dark btn-responsive" onclick="animateModel();">Start</a>
                      <a href="#" class="btn btn-outline-dark btn-responsive" onclick="stopAnimation();">Stop</a>
                      <div class="card-text x3dAnimationDescription modelText">
                        <p>These buttons start and stop the animation for the selected instrument.</p>
                      </div>
                    </div>
                    <div id="renderControls">
                      <div class="card-Title x3dRendersubtitle modelText">
                        <h2>Render Options</h2>
                      </div>
                      <br>
                      <a id="wirebutton" href="#" class="btn btn-primary btn-responsive" onclick="wireframe();">Wire</a>
                      <a id="colorbutton" href="#" class="btn btn-primary btn-responsive" onclick="changeColour(1);">Colour 1</a>
                      <a id="colorbutton" href="#" class="btn btn-primary btn-responsive" onclick="changeColour(2);">Colour 2</a>
                      <a id="colorbackbutton" href="#" class="btn btn-primary btn-responsive" onclick="changeToOriginalColour();">Original</a>
                      <div class="card-text x3dRenderDescription modelText">
                        <p>These buttons show the wireframe and different coloured versions of the instrument.</p>
                      </div>
                    </div>
                    <div id="lightingControls">
                      <div class="card-Title x3dRendersubtitle modelText">
                        <h2>Lighting Options</h2>
                      </div>
                      <br>
                      <a id="hlbutton" href="#" class="btn btn-secondary btn-responsive" onclick="headlight();">Headlight On/Off</a>
                      <div class="card-text x3dRenderDescription modelText">
                        <p>This toggles the lights in the scene on and off:</p>
                      </div>
                      <a id="omnibutton" href="#" class="btn btn-secondary btn-responsive" onclick="omniAll();">All</a>
                      <div class="card-text x3dRenderDescription modelText">
                        <p>These buttons allow selection of lighting options.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- X3D Models — Place 4 models in here for the assignment -->
          <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="card text-left">
              <div id="modelsPanel">
                <div class="card-header">
                  <ul class="nav nav-tabs card-header-tabs">
                    <li class="nav-item">
                      <a id="navRecorder" class="nav-link active" href="#">Recorder</a>
                    </li>
                    <li class="nav-item">
                      <a id="navBugle" class="nav-link" href="#">Bugle</a>
                    </li>
                    <li class="nav-item">
                      <a id="navXylophone" class="nav-link" href="#">Xylophone</a>
                    </li>
                    <li class="nav-item">
                      <a id="navHarmonica" class="nav-link" href="#">Harmonica</a>
                    </li>
                    <li class="nav-item">
                      <a id="navMaracas" class="nav-link" href="#">Maracas</a>
                    </li>
                    <li class="nav-item">
                      <a id="navCymbals" class="nav-link" href="#">Cymbals</a>
                    </li>
                  </ul>
                </div>
                <div class="modelModifiers">
                  <div class="card-body">
                    <!-- Recorder X3D model -->
                    <div id="recorder">
                      <div id="x3dModelT1" class="card-title modelText">
                        <h2><?php echo $data[1][0]['x3dModelTitle'] ?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model1">
                          <scene>
                            <inline nameSpaceName="modelRec" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][0]['modelUrl']?>" > </inline>
                          </scene>
                        </x3d>
                      </div>
                      <div id="x3dCM1" class="card-text descText">
                        <p><?php echo $data[1][0]['x3dCreationMethod'] ?></p>
                      </div>
                    </div>
                    <!-- Bugle X3D model -->
                    <div id="bugle" style="display:none;">
                      <div id="x3dModelT2" class="card-title modelText">
                        <h2><?php echo $data[1][1]['x3dModelTitle']?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model2">
                          <scene>
                            <inline nameSpaceName="modelBug" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][1]['modelUrl']?>"> </inline>
                          </scene>
                        </x3d>
                      </div> 
                      <div id="x3dCM2" class="card-text descText">
                        <p><?php echo $data[1][1]['x3dCreationMethod'] ?></p>
                      </div>
                    </div>
                    <!-- Xylophone X3D model -->
                    <div id="xylophone" style="display:none;">
                      <div id="x3dModelT3" class="card-title modelText">
                        <h2><?php echo $data[1][2]['x3dModelTitle']?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model3">
                          <scene>
                            <inline nameSpaceName="modelXy" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][2]['modelUrl']?>"> </inline>
                          </scene>
                        </x3d>
                      </div> 
                      <div id="x3dCM3" class="card-text descText">
                        <p><?php echo $data[1][2]['x3dCreationMethod'] ?></p>
                      </div>
                    </div>
                    <!-- Harmonica X3D model -->
                    <div id="harmonica" style="display:none;">
                      <div id="x3dModelT4" class="card-title modelText">
                        <h2><?php echo $data[1][3]['x3dModelTitle']?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model4">
                          <scene>
                            <inline nameSpaceName="modelHar" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][3]['modelUrl']?>"> </inline>
                          </scene>
                        </x3d>
                      </div> 
                      <div id="x3dCM4" class="card-text descText">
                        <p><?php echo $data[1][3]['x3dCreationMethod'] ?><p>
                      </div>
                    </div>
                    <!-- Maracas X3D model -->
                    <div id="maracas" style="display:none;">
                      <div id="x3dModelT5" class="card-title modelText">
                        <h2><?php echo $data[1][4]['x3dModelTitle']?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model5"> 
                          <scene>
                            <inline nameSpaceName="modelMar" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][4]['modelUrl']?>"> </inline>
                          </scene>
                        </x3d>
                      </div> 
                      <div id="x3dCM5" class="card-text descText">
                        <p><?php echo $data[1][4]['x3dCreationMethod'] ?><p>
                      </div>
                    </div>
                    <!-- Maracas X3D model -->
                    <div id="cymbals" style="display:none;">
                      <div id="x3dModelT6" class="card-title modelText">
                        <h2><?php echo $data[1][5]['x3dModelTitle']?></h2>
                      </div>
                      <!-- Place the X3D code here -->
                      <div class="model3D">
                        <x3d id="model6">
                          <scene>
                            <inline nameSpaceName="modelCym" mapDEFToID="true" onclick="animateModel();" url="<?php echo $data[1][5]['modelUrl']?>"> </inline>
                          </scene>
                        </x3d>
                      </div> 
                      <div id="x3dCM6" class="card-text descText">
                        <p><?php echo $data[1][5]['x3dCreationMethod'] ?><p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 3D image gallery -->
          <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
            <div class="card text-left">
              <div id="galleryPanel">
                <div class="card-header gallery-header">
                  <ul class="nav nav-tabs card-header-tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#">Gallery</a>
                    </li>
                  </ul>
                </div>
                <div class="modelModifiers">
                  <div class="card-body">
                    <div class="card-title title_gallery galleryText"></div>
                    <div class="gallery" id="gallery"></div>
                    <div class="card-text description_gallery galleryText"></div>
                  </div>
                </div>
              </div>
            </div> <!-- End gallery card -->
          </div> <!-- End gallery column -->
        </div> <!-- End row for X3D Model and Gallery -->
      </div> <!-- End X3D Models and Gallery -->
        
      <div id="statement">
        <h2><?php echo $data[2][0]['paragraph'] ?></h2>
        <p><?php echo $data[2][1]['paragraph'] ?><p>
        <p><?php echo $data[2][2]['paragraph'] ?><p>
        <p><?php echo $data[2][3]['paragraph'] ?><p>
      </div>

      <div id="references">
        <h2><?php echo $data[2][4]['paragraph'] ?></h2>
        <p>The website itself has been adapted from that provided in the Lab Exercises by Martin White.</p>
        <br>
        <p><?php echo $data[2][5]['paragraph'] ?><p>
        <p><?php echo $data[2][6]['paragraph'] ?><p>
        <p><?php echo $data[2][7]['paragraph'] ?><p>
        <p><?php echo $data[2][8]['paragraph'] ?><p>
        <p><?php echo $data[2][10]['paragraph'] ?><p>
        <p><?php echo $data[2][11]['paragraph'] ?><p>
        <p><?php echo $data[2][12]['paragraph'] ?><p>
        <p><?php echo $data[2][13]['paragraph'] ?><p>
        <p><?php echo $data[2][14]['paragraph'] ?><p>
        <p><?php echo $data[2][15]['paragraph'] ?><p>
        <p><?php echo $data[2][16]['paragraph'] ?><p>
        <p><?php echo $data[2][17]['paragraph'] ?><p>
        <p><?php echo $data[2][18]['paragraph'] ?><p>
        <p><?php echo $data[2][19]['paragraph'] ?><p>
        <p><?php echo $data[2][20]['paragraph'] ?><p>
        <p><?php echo $data[2][21]['paragraph'] ?><p>
        <p><?php echo $data[2][22]['paragraph'] ?><p>
        <p><?php echo $data[2][23]['paragraph'] ?><p>
        <p><?php echo $data[2][24]['paragraph'] ?><p>
        <p><?php echo $data[2][25]['paragraph'] ?><p>
        <p><?php echo $data[2][26]['paragraph'] ?><p>
        <p><?php echo $data[2][27]['paragraph'] ?><p>
        <p><?php echo $data[2][28]['paragraph'] ?><p>
        <p><?php echo $data[2][29]['paragraph'] ?><p>
        <p><?php echo $data[2][30]['paragraph'] ?><p>
        <p><?php echo $data[2][31]['paragraph'] ?><p>
        <p><?php echo $data[2][32]['paragraph'] ?><p>
        <p><?php echo $data[2][33]['paragraph'] ?><p>
        <p><?php echo $data[2][34]['paragraph'] ?><p>
        <p><?php echo $data[2][35]['paragraph'] ?><p>
        <p><?php echo $data[2][36]['paragraph'] ?><p>
        <p><?php echo $data[2][37]['paragraph'] ?><p>
      </div>

      <div id="deepund">
        <h2><?php echo $data[2][38]['paragraph'] ?></h2>
        <p><?php echo $data[2][39]['paragraph'] ?><p>
        <p><?php echo $data[2][40]['paragraph'] ?><p>
        <p><?php echo $data[2][41]['paragraph'] ?><p>
        <p><?php echo $data[2][42]['paragraph'] ?><p>
        <p><?php echo $data[2][43]['paragraph'] ?><p>
        <p><?php echo $data[2][44]['paragraph'] ?><p>
        <p><?php echo $data[2][45]['paragraph'] ?><p>
        <p><?php echo $data[2][46]['paragraph'] ?><p>
        <p><?php echo $data[2][47]['paragraph'] ?><p>
        <p><?php echo $data[2][48]['paragraph'] ?><p>
      </div>

      <div id="files">
        <h2><?php echo $data[2][49]['paragraph'] ?></h2>
        <p><?php echo $data[2][50]['paragraph'] ?><p>
        <p><?php echo $data[2][51]['paragraph'] ?><p>
        <p><?php echo $data[2][52]['paragraph'] ?><p>
      </div>

      <!-- Row to hold one card to hold the recorder descriptive text, etc.-->
      <div id="recorderDescription">
        <div class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleR" class="card-title descText">
                  <h2><?php echo $data[1][0]['title'] ?></h2>
                </div>
                <div id="subTitleR" class="card-subtitle descText">
                  <h3><?php echo $data[1][0]['subTitle'] ?></h3>
                </div>
                <div id="descriptionR" class="card-text descText">
                  <p><?php echo $data[1][0]['modelDescription'] ?></p>
                </div>  
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End recorder description contents -->

      <!-- Row to hold one card to hold the bugle descriptive text, etc.-->
      <div id="bugleDescription">
        <div class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleB" class="card-title descText">
                  <h2><?php echo $data[1][1]['title'] ?></h2>
                </div>
                <div id="subTitleB" class="card-subtitle descText">
                  <h3><?php echo $data[1][1]['subTitle'] ?></h3>
                </div>
                <div id="descriptionB" class="card-text descText">
                  <p><?php echo $data[1][1]['modelDescription'] ?></p>
                </div>  
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End bugle description contents -->

      <!-- Row to hold one card to hold the xylophone descriptive text, etc.-->
      <div id="xylophoneDescription">
        <div class="row" >
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleX" class="card-title descText">
                  <h2><?php echo $data[1][2]['title'] ?></h2>
                </div>
                <div id="subTitleX" class="card-subtitle descText">
                  <h3><?php echo $data[1][2]['subTitle'] ?></h3>
                </div>
                <div id="descriptionX" class="card-text descText">
                  <p><?php echo $data[1][2]['modelDescription'] ?></p>
                </div>  
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End xylophone description contents -->  

      <!-- Row to hold one card to hold the harmonica descriptive text, etc.-->
      <div id="harmonicaDescription">
        <div class="row" >
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleH" class="card-title descText">
                  <h2><?php echo $data[1][3]['title'] ?></h2>
                </div>
                <div id="subTitleH" class="card-subtitle descText">
                  <h3><?php echo $data[1][3]['subTitle'] ?></h3>
                </div>
                <div id="descriptionH" class="card-text descText">
                  <p><?php echo $data[1][3]['modelDescription'] ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End harmonica description contents -->  

      <!-- Row to hold one card to hold the maracas descriptive text, etc.-->
      <div id="maracasDescription">
        <div class="row" >
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleM" class="card-title descText">
                  <h2><?php echo $data[1][4]['title'] ?></h2>
                </div>
                <div id="subTitleM" class="card-subtitle descText">
                  <h3><?php echo $data[1][4]['subTitle'] ?></h3>
                </div>
                <div id="descriptionM" class="card-text descText">
                  <p><?php echo $data[1][4]['modelDescription'] ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End maracas description contents -->  

      <!-- Row to hold one card to hold the maracas descriptive text, etc.-->
      <div id="cymbalsDescription">
        <div class="row" >
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div id="titleC" class="card-title descText">
                  <h2><?php echo $data[1][5]['title'] ?></h2>
                </div>
                <div id="subTitleC" class="card-subtitle descText">
                  <h3><?php echo $data[1][5]['subTitle'] ?></h3>
                </div>
                <div id="descriptionC" class="card-text descText">
                  <p><?php echo $data[1][5]['modelDescription'] ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End maracas description contents -->  
      

    </div>  <!-- End 3D App SPA Contents --> 

    <!-- Your 3D App footer -->
    <nav id="footerColor" class="navbar navbar-expand-sm footer">
      <div class="container-fluid">   
        <div class="navbar-text float-left copyright">
          <p><span class="align-baseline">&copy 2020 3D Apps | <a href="javascript:changeLook()">Restyle</a> | <a href="javascript:changeBack()">Reset</a> | <a id="navStatement" href="#">Statement</a> | <a id="navReferences" href="#">References</a> | <a id="navDeepUnd" href="#">Deeper Understanding</a> | <a id="navFiles" href="#">Files</a></span></p>
        </div>
      </div>
    </nav> 

    <!-- My 3D App modals -->
    <!-- Contact modal -->
    <!-- The Modal -->
    <div class="modal fade" id="contactModal">
      <div class="modal-dialog">
        <div class="modal-content">
        
          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">3D App Contact Details</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
        
          <!-- Modal body -->
          <div class="modal-body">
              <p>Candidate Number: 164733, Email: elp25@sussex.ac.uk</p>
          </div>
        
          <!-- Modal footer -->
          <div class="modal-footer">
              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
          </div>
        
        </div>
      </div>
    </div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/popper.min.js"></script>
    <!--<script src="js/bootstrap.js"></script>-->
    <script src="js/bootstrap-4.4.1.js"></script>

    <!-- Include the x3dom JavaScript -->
    <script src='js/x3dom.js'></script>

    <!-- Font Awesome Version 5 -->
    <!-- <script src="https://kit.fontawesome.com/6ac3910c4e.js" crossorigin="anonymous"></script> -->
    <!-- <script src="all.js"></script> -->

    <!-- Custom JavaScript code for your 3d App -->
    <!-- Also, intialises popovers-->
    <script src="js/custom.js" crossorigin="anonymous"></script>

    <!-- JavaScript to swap for SPA and restyle -->
    <script src="js/swap_restyle.js"></script>

    <!-- JavaScript and PHP based Gallery generator  -->
    <script src="js/gallery_generator.js"></script>

    <!-- JQuery code to get content data from a backend JSON file -->
    <!--script src="../../scripts/js/getJsonData.js"></script-->

    <!-- JavaScript model interactions -->
    <script src="js/modelInteractions.js"></script>

    <!--fancyBox3 => http://fancyapps.com/fancybox/3/ -->
    <script src="js/jquery.fancybox.min.js"></script>

  </body>
</html>

