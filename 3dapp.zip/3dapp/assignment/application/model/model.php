<?php
class Model {
    // Property declaration, in this case we are declaring a variable or handler that points to database connection, this will become a PDO object
    public $dbhandle;

    // Method to create database connection using PHP Data Objects (PDO) as the interface to SQLite
    public function __construct()
    {
        // Set up the database source name (DSN)
        $dsn = 'sqlite:./db/db1.db';

        // Then create connection to database with PDO() function
        try {
            // Change connection string for different databases, currently using SQLite
            $this->dbhandle = new PDO($dsn, 'user', 'password', array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
            ));
            // $this->dbhandle->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo 'Database connection created</br></br>';
        }
        catch (PDOException $e) {
            echo "I'm sorry, Emma. I'm afraid I can't connect to the database!";
            // Generate an error message if the connection fails
            print new Exception($e->getMessage());
        }
    }

    // This is a simple fix to represent what would in reality be a table in the db containing the brand names
    // DB schema would contain a foreign key for each drink entry linking back to brand name
    // This structure allows us to read the list of brand names to populate a menu in a view
    public function getHomeDescResult() 
    {
        try {
            //Prepare a statement to get all records from Model_3D table
            $sql = 'SELECT * FROM HomeDesc';
            // Use PDO query() to query the database with the prepared SQL statement
            $stmt = $this->dbhandle->query($sql);
            // Set up arrays to return the results to the view
            $homeDescResult = null;
            // Set up a variable to index each row of the array
            $i=-0;
            // Use PDO fetch() to retrieve the results from the database using a while loop
            // Use a while loop to loop through the rows
            while($data = $stmt->fetch()) {
                // Write db contents to results array for sending back to view
                $homeDescResult[$i]['title'] = $data['title'];
                $homeDescResult[$i]['subTitle'] = $data['subTitle'];
                $homeDescResult[$i]['picDescription'] = $data['picDescription'];
                // increment row index
                $i++;
            }
        }
        catch(PDOException $e) {
            print new Exception($e->getMessage());
        }
        // Send response back to view
        return $homeDescResult;
    }

    public function getModelDescResult() 
    {
        try {
            //Prepare a statement to get all records from Model_3D table
            $sql = 'SELECT * FROM ModelDesc';
            // Use PDO query() to query the database with the prepared SQL statement
            $stmt = $this->dbhandle->query($sql);
            // Set up arrays to return the results to the view
            $modelDescResult = null;
            // Set up a variable to index each row of the array
            $i=-0;
            // Use PDO fetch() to retrieve the results from the database using a while loop
            // Use a while loop to loop through the rows
            while($data = $stmt->fetch()) {
                // Simple test to check we can output value from db in while loop
                // echo '</br>' . $data['x3dModelTitle'];
                // Write db contents to results array for sending back to view
                $modelDescResult[$i]['x3dModelTitle'] = $data['x3dModelTitle'];
                $modelDescResult[$i]['x3dCreationMethod'] = $data['x3dCreationMethod'];
                $modelDescResult[$i]['title'] = $data['title'];
                $modelDescResult[$i]['subTitle'] = $data['subTitle'];
                $modelDescResult[$i]['modelDescription'] = $data['modelDescription'];
                $modelDescResult[$i]['modelUrl'] = $data['modelUrl'];
                // increment row index
                $i++;
            }
        }
        catch(PDOException $e) {
            print new Exception($e->getMessage());
        }
        // Send response back to view
        return $modelDescResult;
    }

    public function getMetaDataDescResult() 
    {
        try {
            //Prepare a statement to get all records from Model_3D table
            $sql = 'SELECT * FROM MetaDataDesc';
            // Use PDO query() to query the database with the prepared SQL statement
            $stmt = $this->dbhandle->query($sql);
            // Set up arrays to return the results to the view
            $metaDataDescResult = null;
            // Set up a variable to index each row of the array
            $i=-0;
            // Use PDO fetch() to retrieve the results from the database using a while loop
            // Use a while loop to loop through the rows
            while($data = $stmt->fetch()) {
                // Simple test to check we can output value from db in while loop
                // echo '</br>' . $data['x3dModelTitle'];
                // Write db contents to results array for sending back to view
                $metaDataDescResult[$i]['paragraph'] = $data['paragraph'];
                // increment row index
                $i++;
            }
        }
        catch(PDOException $e) {
            print new Exception($e->getMessage());
        }
        // Send response back to view
        return $metaDataDescResult;
    }


    public function dbCreateTables()
    {
        try {
            $this->dbhandle->exec("DROP TABLE IF EXISTS HomeDesc");
            $this->dbhandle->exec("CREATE TABLE HomeDesc (Id INTEGER PRIMARY KEY, title TEXT, subTitle TEXT, picDescription TEXT)");
            $this->dbhandle->exec("DROP TABLE IF EXISTS ModelDesc");
            $this->dbhandle->exec("CREATE TABLE ModelDesc (Id INTEGER PRIMARY KEY, x3dModelTitle TEXT, x3dCreationMethod TEXT, title TEXT, subTitle TEXT, modelDescription TEXT, modelUrl TEXT)");
            $this->dbhandle->exec("DROP TABLE IF EXISTS MetaDataDesc");
            $this->dbhandle->exec("CREATE TABLE MetaDataDesc (Id INTEGER PRIMARY KEY, paragraph TEXT)");
            
            return "HomeDesc, ModelDesc and MetaDataDesc tables are successfully created inside db1.db file";
        }
        catch (PDOException $e) {
            print new Exception($e->getMessage());
        }
        $this->dbhandle = NULL;
    }

    public function dbInsertData() 
    {
        try {
            $this->dbhandle->exec(
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (1, 'Museum of Instruments', 'Music of the World', 'Our site is dedicated to teaching you something you never knew about music - whether you''re a beginner or a concert pianist, there''s something here for everyone!');" .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (2, 'Recorder', 'Woodwind', 'The Recorder is a type of flute with a whistle mouthpiece and a thumb hole. It comes in different sizes, with each corresponding to different vocal ranges (soprano, alto, tenor and bass) and the most common being the Soprano. It originated in Europe in the Middle Ages and became a staple instrument in the Renaissance and Baroque periods.'); " .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (3, 'Bugle', 'Brass', 'The Bugle is one of the earliest brass instruments. It is a simple instrument with no valves and therefore the pitch of the notes produced cannot be altered this way and is instead altered through the shape of one''s mouth. It is commonly used in the Military and is most widely heard playing The Last Post.'); " .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (4, 'Xylophone', 'Percussion', 'The Xylophone is a type of percussion instrument that produces sound by being struck by mallets. It is comprised of a set of tuned keys laid out a little like those on the piano and was developed around the 9th century.'); " .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (5, 'Harmonica', 'Woodwind', 'The harmonica is a wind instrument played by blowing air into or out of the holes on the mouthpiece. It is also known as the French harp or mouth organ and has been used predominantly in blues and jazz music. It came about around the early 19th century.'); " .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (6, 'Maracas', 'Percussion', 'The maracas are a type of percussion instrument containing pebbles that are shaken to create a rattling sound. They are commonly used in genres of Caribbean and Latin music, as well as being popular among Indian tribes.'); " .
            "INSERT INTO HomeDesc (Id, title, subTitle, picDescription)
                VALUES (7, 'Cymbals', 'Percussion', 'The cymbals are an unpitched percussion instrument that is used in a wide variety of settings, such as orchestras, jazz bands and marching groups. They originated around the time of the 7th century BC where ancient relics and paintings have been found depicting them.'); ");

            $this->dbhandle->exec(
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (1, 'Recorder X3D Model', 'Make sure you have your sound switched on!', 'Recorder - Woodwind', 'Creating the model', 'The recorder was created by using a picture of one on a plane as a template and then creating a cylinder and extruding it to match the shape on the plane. This technique was taken from the Lab 2 modelling of the Sprite bottle. Holes were then cut out of the model, a shell was applied and it was textured using the appropriate material.', 'assets/x3d/recorder.x3d'); " .
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (2, 'Bugle X3D Model', 'Make sure you have your sound switched on!', 'Bugle - Brass', 'Creating the model', 'The bugle was created in a similar way to the recorder (and thus the Sprite bottle in the lab exercises). A cylinder was created and extruded to create the shape of the bugle, using a picture with a plane. It was then split into two separate models (one for the mouthpiece and one for the main body) which were then shelled and textured separately.', 'assets/x3d/bugle.x3d'); " .
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (3, 'Xylophone X3D Model', 'Make sure you have your sound switched on!', 'Xylophone - Percussion', 'Creating the model', 'The xylophone was created by building the wooden base first and then modelling the keys and mallets separately as different models. Once the shapes were right, these were textured using images from the internet and materials, and combined to form one object.', 'assets/x3d/xylophone.x3d'); " .
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (4, 'Harmonica X3D Model', 'Make sure you have your sound switched on!', 'Harmonica - Woodwind', 'Creating the model', 'The harmonica was created by using a picture of one on a plane and modelling the shape of it by extruding a cuboid. The holes were cut out last and the whole thing was textured using materials before being exported.', 'assets/x3d/harmonica.x3d'); " .
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (5, 'Maracas X3D Model', 'Make sure you have your sound switched on!', 'Maracas - Percussion', 'Creating the model', 'The maracas were created in Blender and used the same technique as with the Sprite bottle. A texture was then created by importing the UV map into Photoshop and adding colours.', 'assets/x3d/maracas.x3d'); " .
            "INSERT INTO ModelDesc (Id, x3dModelTitle, x3dCreationMethod, title, subTitle, modelDescription, modelUrl)
                VALUES (6, 'Cymbals X3D Model', 'Make sure you have your sound switched on!', 'Cymbals - Percussion', 'Creating the model', 'The cymbals, like the maracas, were created in Blender and were shaped by extruding a relatively flat cylinder. The handles of the cymbals were made afterwards using extruded cubes and this was all textured using the UV maps in Photoshop.', 'assets/x3d/cymbals.x3d'); ");
            
            $this->dbhandle->exec(
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (1, 'Statement of Originality'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (2, 'These web pages are submitted as part requirement for the degree of Computing for Digital Media at the University of Sussex.'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (3, 'They are the product of my own labour except where indicated in the web page content.'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (4, 'These web pages or contents may be freely copied and distributed provided the source is acknowledged.'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (5, 'References'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (6, '1. Recorder Sound Effect - https://www.youtube.com/watch?v=J6BsnF74RlI'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (7, '2. Bugle, Xylophone, Harmonica, Maracas and Cymbals Sound Effects - https://www.youtube.com/watch?reload=9&v=yh_gXf_VK9g'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (8, '3. Girassol Font - https://fonts.google.com/specimen/Girassol'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (9, '4. Oswald Font - https://www.fontsquirrel.com/fonts/oswald'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (10, '5. Open-Sans Font - https://fonts.google.com/specimen/Open+Sans'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (11, '6. Background for Recorder Gallery Image - https://www.cityoftrees.org.uk/gowild'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (12, '7. Background for Bugle Gallery Image - https://www.britishlegion.org.uk/get-involved/remembrance/about-remembrance/in-flanders-field'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (13, '8. Background for Xylophone Gallery Image - https://commons.wikimedia.org/wiki/File:London_Barbican_Hall_LSO_Haitink.jpg'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (14, '9. Background for Harmonica Gallery Image - https://readtiger.com/wkp/en/Jimmie_Noone'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (15, '10. Background for Maracas Gallery Image - https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.dailymotion.com%2Fvideo%2Fx2yuhnc&psig=AOvVaw1K8UgfkldgjR2Nv7k6JFc7&ust=1589542779392000&source=images&cd=vfe&ved=0CA0QjhxqFwoTCKCcn7mis-kCFQAAAAAdAAAAABAD'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (16, '11. Background for Cymbals Gallery Image - https://content.invisioncic.com/l282353/monthly_2015_06/Dronesdrums.jpg.adb49a6dd23088f965b8d74ce495db8e.jpg'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (17, '12. Recorder Homepage Image - https://earlymusicshop.com/products/yamaha-302b-soprano-recorder'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (18, '13. Bugle Homepage Image - https://muzikus.sk/sk/polnice-a-lovecke-nastroje-a-prislusenstvo-c-1420'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (19, '14. Xylophone Homepage Image - https://www.jampercussion.com/buy/concorde-x1001-2-5-octave-table-top-xylophone_819.htm'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (20, '15. Harmonica Homepage Image - https://www.google.com/url?sa=i&url=https%3A%2F%2Fsonnyboysmusicstore.co.uk%2Fproducts%2Fdabell-nobel-diatonic-harmonica-in-key-of-c&psig=AOvVaw3b4gFBxDuUGRDEF7iIINOE&ust=1589543548329000&source=images&cd=vfe&ved=0CA0QjhxqFwoTCLj-7aals-kCFQAAAAAdAAAAABAE'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (21, '16. Maracas Homepage Image - https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.fruugo.co.uk%2Fworld-rhythm-natural-hand-painted-wooden-maracas-small%2Fp-30148199-63310686&psig=AOvVaw3glO1ZbbxX9cwFUh5PTqZ7&ust=1589543486967000&source=images&cd=vfe&ved=0CA0QjhxqFwoTCMijqYqls-kCFQAAAAAdAAAAABAI'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (22, '17. Cymbals Homepage Image - https://www.cbc.ca/radio/undertheinfluence/brand-envy-canada150-1.4108158'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (23, '18. Main Homepage Image - https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.netclipart.com%2Fisee%2Fxowh_colorful-music-clipart-transparent-background-music-notes-png%2F&psig=AOvVaw0oDm7tNOX8xmkXi5PKwvA_&ust=1589543671825000&source=images&cd=vfe&ved=0CA0QjhxqFwoTCPjx0uGls-kCFQAAAAAdAAAAABAD'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (24, '19. Wood Texture 1 for the Xylophone - https://unsplash.com/photos/e6frrz-kh-0'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (25, '20. Wood Texture 2 for the Xylophone - https://www.wildtextures.com/free-textures/wood/golden-brown-wooden-surface/'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (26, '21. Wood Texture 3 for the Xylophone - https://unblast.com/3-free-seamless-oak-wood-textures-jpg/'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (27, '22. Gold Texture for the Cymbals - https://www.shutterstock.com/search/cymbal+texture'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (28, '23. Leather Texture for the Cymbals - https://www.freepik.com/free-photos-vectors/black-leather-texture'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (29, '24. bootstrap-4.4.1 JS and CSS Files - https://getbootstrap.com/'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (30, '25. jquery.fancybox.min JS and CSS Files - https://github.com/fancyapps/fancyBox'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (31, '26. jquery-3.4.1.js - https://www.nuget.org/packages/jQuery/3.4.1'); " .  
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (32, '27. popper.min.js - https://popper.js.org/'); " .  
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (33, '28. x3dom JS and CSS Files - https://www.x3dom.org/'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (34, '29. fa-brands-400.ttf, fa-brands-400.woff and fa-brans-400.woff2 - https://github.com/FortAwesome/Font-Awesome/tree/master/webfonts'); " .         
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (35, '30. Archiving a 3DS Max File - https://knowledge.autodesk.com/support/3ds-max/learn-explore/caas/CloudHelp/cloudhelp/2019/ENU/3DSMax-Manage-Scenes/files/GUID-8C655DD1-1A16-40FE-9C51-386AEB0C60A6-htm.html'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (36, '31. Toggling Lights in X3DOM - https://doc.x3dom.org/tutorials/lighting/lights/'); " .  
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (37, '32. Capturing a Still Image from 3DS Max - https://knowledge.autodesk.com/support/3ds-max/learn-explore/caas/CloudHelp/cloudhelp/2015/ENU/3DSMax/files/GUID-78DBE871-32CB-4171-8A81-37C94C37481E-htm.html'); " .     
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (38, '33. Adding Sound to X3DOM - https://doc.x3dom.org/tutorials/basics/sound/index.html'); " .   
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (39, 'Deeper Understanding'); " .   
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (40, '1. Six models were created instead of the four that were required, and two of these were made in Blender.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (41, '2. Blender was used for the Maracas and Cymbals 3D models. These were also textured with designs made in Photoshop which were then made into a Blender UV Map.'); " .     
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (42, '3. The gallery was extended to have a different image show when clicking on the thumbnail (instead of displaying the same image as the thumbnail).'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (43, '4. There are buttons to modify the textures on each model.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (44, '5. A sound plays when each model is clicked on.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (45, '6. Some of the models are relatively complex, with the Xylophone being particularly time consuming to model.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (46, '7. Some of the animations created for the models relate to the models themselves, such as the Xylophone animation - it was also not possible to export animation from Blender to X3D so the Blender models have no animation.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (47, '8. Created 5 different page layouts for different device sizes.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (48, '9. Some of the code in the swap_restyle.js and modelInteractions.js files is beyond the scope of the Lab classes.'); " . 
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (49, '10. Used the MVC model to store more data and extend the functionality of that in the Labs.'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (50, 'Files'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (51, '1. Models - https://github.com/chopsone/models'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (52, '2. Archives - https://github.com/chopsone/archives'); " .
            "INSERT INTO MetaDataDesc (Id, paragraph)
                VALUES (53, '3. Codebase - https://github.com/chopsone/code'); ");

            return "X3D model data inserted successfully inside db1.db";
        }
        catch (PDOException $e) {
            print new Exception($e->getMessage());
        }
        $this->dbhandle = NULL;
    }

    public function getDBResult() {
        $modelData = $this->getModelDescResult();
        $homeData = $this->getHomeDescResult();
        $metaData = $this->getMetaDataDescResult();

        $result = null;

        $result[0] = $homeData;
        $result[1] = $modelData;
        $result[2] = $metaData;

        $this->dbhandle = NULL;

        return $result;
    }

}
?>