<?php
// You can define config variables here

// Display error message caused by PHP scripts
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// The require or include statement takes all text/code/markup that exists
// in specified file and copies it into file that uses include or require statement
require 'application/mvc.php';
?>