//adapted from example code 'benskitchen.com'

function play(obj) {
	document.getElementById(obj + '__audio').setAttribute('enabled', 'true');
}

function stop(obj) {
	document.getElementById(obj + '__audio').setAttribute('enabled', 'false');
}

function wireframe()
{
	var rec = document.getElementById('model1');
	rec.runtime.togglePoints(true);
	rec.runtime.togglePoints(true);
	var bug = document.getElementById('model2');
	bug.runtime.togglePoints(true);
	bug.runtime.togglePoints(true);
	var xy = document.getElementById('model3');
	xy.runtime.togglePoints(true);
	xy.runtime.togglePoints(true);
	var har = document.getElementById('model4');
	har.runtime.togglePoints(true);
	har.runtime.togglePoints(true);
	var mar = document.getElementById('model5');
	mar.runtime.togglePoints(true);
	mar.runtime.togglePoints(true);
	var cym = document.getElementById('model6');
	cym.runtime.togglePoints(true);
	cym.runtime.togglePoints(true);
}

var lightOn = false;

function headlight()
{
	lightOn = !lightOn;
	document.getElementById('modelRec__NavInfo001').setAttribute('headlight', lightOn.toString());
	document.getElementById('modelBug__NavInfo001').setAttribute('headlight', lightOn.toString());
	document.getElementById('modelXy__NavInfo001').setAttribute('headlight', lightOn.toString());
	document.getElementById('modelHar__NavInfo001').setAttribute('headlight', lightOn.toString());
	document.getElementById('modelMar__NavInfo001').setAttribute('headlight', lightOn.toString());
	document.getElementById('modelCym__NavInfo001').setAttribute('headlight', lightOn.toString());
	if(lightOn) {
		document.getElementById('hlbutton').classList.add('btn-primary');
		document.getElementById('hlbutton').classList.remove('btn-secondary');
	} else {
		document.getElementById('hlbutton').classList.remove('btn-primary');
		document.getElementById('hlbutton').classList.add('btn-secondary');
	}
	
}

var omnilights = 'TRUE';

function omniAll() {
	if(omnilights == 'FALSE')
		omnilights = 'TRUE';
	else
		omnilights = 'FALSE';
	document.getElementById('modelRec__Omni001').setAttribute('on', omnilights);
	document.getElementById('modelBug__Omni001').setAttribute('on', omnilights);
	document.getElementById('modelXy__Omni001').setAttribute('on', omnilights);
	document.getElementById('modelHar__Omni001').setAttribute('on', omnilights);
	document.getElementById('modelMar__Omni001').setAttribute('on', omnilights);
	document.getElementById('modelCym__Omni001').setAttribute('on', omnilights);

	document.getElementById('modelRec__Omni002').setAttribute('on', omnilights);
	document.getElementById('modelBug__Omni002').setAttribute('on', omnilights);
	document.getElementById('modelXy__Omni002').setAttribute('on', omnilights);
	document.getElementById('modelHar__Omni002').setAttribute('on', omnilights);
	document.getElementById('modelMar__Omni002').setAttribute('on', omnilights);
	document.getElementById('modelCym__Omni002').setAttribute('on', omnilights);

	document.getElementById('modelRec__Omni003').setAttribute('on', omnilights);
	document.getElementById('modelBug__Omni003').setAttribute('on', omnilights);
	document.getElementById('modelXy__Omni003').setAttribute('on', omnilights);
	document.getElementById('modelHar__Omni003').setAttribute('on', omnilights);
	document.getElementById('modelMar__Omni003').setAttribute('on', omnilights);
	document.getElementById('modelCym__Omni003').setAttribute('on', omnilights);

	document.getElementById('modelRec__Omni004').setAttribute('on', omnilights);
	document.getElementById('modelBug__Omni004').setAttribute('on', omnilights);
	document.getElementById('modelXy__Omni004').setAttribute('on', omnilights);
	document.getElementById('modelHar__Omni004').setAttribute('on', omnilights);
	document.getElementById('modelMar__Omni004').setAttribute('on', omnilights);
	document.getElementById('modelCym__Omni004').setAttribute('on', omnilights);
}

function animateModel() {
	document.getElementById('modelRec__Cylinder001-TIMER').setAttribute('enabled', 'true');
	document.getElementById('modelBug__Cylinder001-TIMER').setAttribute('enabled', 'true');
	document.getElementById('modelXy__Sphere001-TIMER').setAttribute('enabled', 'true');
	document.getElementById('modelXy__Sphere002-TIMER').setAttribute('enabled', 'true');
	document.getElementById('modelHar__Box001-TIMER').setAttribute('enabled', 'true');
	document.getElementById('modelHar__Box002-TIMER').setAttribute('enabled', 'true');

	document.getElementById('modelRec__Cylinder001-TIMER').setAttribute('loop', 'true');
	document.getElementById('modelBug__Cylinder001-TIMER').setAttribute('loop', 'true');
	document.getElementById('modelXy__Sphere001-TIMER').setAttribute('loop', 'true');
	document.getElementById('modelXy__Sphere002-TIMER').setAttribute('loop', 'true');
	document.getElementById('modelHar__Box001-TIMER').setAttribute('loop', 'true');
	document.getElementById('modelHar__Box002-TIMER').setAttribute('loop', 'true');
}

function stopAnimation() {
	document.getElementById('modelRec__Cylinder001-TIMER').setAttribute('loop', 'false');
	document.getElementById('modelBug__Cylinder001-TIMER').setAttribute('loop', 'false');
	document.getElementById('modelXy__Sphere001-TIMER').setAttribute('loop', 'false');
	document.getElementById('modelXy__Sphere002-TIMER').setAttribute('loop', 'false');
	document.getElementById('modelHar__Box001-TIMER').setAttribute('loop', 'false');
	document.getElementById('modelHar__Box002-TIMER').setAttribute('loop', 'false');

	document.getElementById('modelRec__Cylinder001-TIMER').setAttribute('enabled', 'false');
	document.getElementById('modelBug__Cylinder001-TIMER').setAttribute('enabled', 'false');
	document.getElementById('modelXy__Sphere001-TIMER').setAttribute('enabled', 'false');
	document.getElementById('modelXy__Sphere002-TIMER').setAttribute('enabled', 'false');
	document.getElementById('modelHar__Box001-TIMER').setAttribute('enabled', 'false');
	document.getElementById('modelHar__Box002-TIMER').setAttribute('enabled', 'false');
}

function changeColour(counter) {
	switch(counter) {
		case 1:
			document.getElementById('modelRec__mat1').setAttribute('diffuseColor', '1 0.1 0.498');
			document.getElementById('modelBug__col1').setAttribute('color', '0.1 0.1 0.5 0.5 0.2 0.6');
			document.getElementById('modelXy__img1').setAttribute('url', '"../maps/woodtexture2.jpg"');
			document.getElementById('modelXy__img2').setAttribute('url', '"../maps/woodtexture2.jpg"');
			document.getElementById('modelXy__img3').setAttribute('url', '"../maps/woodtexture2.jpg"');
			document.getElementById('modelXy__col1').setAttribute('color', '0.1 0.3 0.5 0.5882 0.5882 0.5882');
			document.getElementById('modelHar__col1').setAttribute('color', '0 0 0 0.7 0.4 0.2 0.9 0.6 0');
			document.getElementById('modelCym__img1').setAttribute('url', '"../maps/cymbaluvs1.png"');
			document.getElementById('modelCym__img2').setAttribute('url', '"../maps/cymbaluvs1.png"');
			document.getElementById('modelMar__img1').setAttribute('url', '"../maps/maracas_uvs1.png"');
			document.getElementById('modelMar__img2').setAttribute('url', '"../maps/maracas_uvs1.png"');
			break;
		case 2:
			document.getElementById('modelRec__mat1').setAttribute('diffuseColor', '0.1 0.1 0.5');
			document.getElementById('modelBug__col1').setAttribute('color', '0.4 0.8 0.2 0.1 0.9 0.9');
			document.getElementById('modelXy__img1').setAttribute('url', '"../maps/woodtexture3.jpg"');
			document.getElementById('modelXy__img2').setAttribute('url', '"../maps/woodtexture3.jpg"');
			document.getElementById('modelXy__img3').setAttribute('url', '"../maps/woodtexture3.jpg"');
			document.getElementById('modelXy__col1').setAttribute('color', '0.4 0.8 0.2 0.5882 0.5882 0.5882');
			document.getElementById('modelHar__col1').setAttribute('color', '0 0 0 0.2 0.1 0.5 0.3 0.9 0');
			document.getElementById('modelCym__img1').setAttribute('url', '"../maps/cymbaluvs2.png"');
			document.getElementById('modelCym__img2').setAttribute('url', '"../maps/cymbaluvs2.png"');
			document.getElementById('modelMar__img1').setAttribute('url', '"../maps/maracas_uvs2.png"');
			document.getElementById('modelMar__img2').setAttribute('url', '"../maps/maracas_uvs2.png"');
			break;
	}
}

function changeToOriginalColour() {
	document.getElementById('modelRec__mat1').setAttribute('diffuseColor', '1 0.7686 0.498');
	document.getElementById('modelBug__col1').setAttribute('color', '0.5451 0.5451 0.4745 0.4431 0.298 0.0549');
	document.getElementById('modelXy__img1').setAttribute('url', '"../maps/woodtexture.jpg"');
	document.getElementById('modelXy__img2').setAttribute('url', '"../maps/woodtexture.jpg"');
	document.getElementById('modelXy__img3').setAttribute('url', '"../maps/woodtexture.jpg"');
	document.getElementById('modelXy__col1').setAttribute('color', '0.3294 0.149 0 0.5882 0.5882 0.5882');
	document.getElementById('modelHar__col1').setAttribute('color', '0 0 0 0.5882 0.5882 0.5882 0.6627 0.498 0');
	document.getElementById('modelCym__img1').setAttribute('url', '"../maps/cymbaluvs.png"');
	document.getElementById('modelCym__img2').setAttribute('url', '"../maps/cymbaluvs.png"');
	document.getElementById('modelMar__img1').setAttribute('url', '"../maps/maracas_uvs.png"');
	document.getElementById('modelMar__img2').setAttribute('url', '"../maps/maracas_uvs.png"');

}

function cameraFront()
{
	document.getElementById('modelRec__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__FrontCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.add('btn-primary');
	document.getElementById('cam_front').classList.remove('btn-secondary');
	document.getElementById('cam_back').classList.remove('btn-primary');
	document.getElementById('cam_back').classList.add('btn-secondary');
	document.getElementById('cam_top').classList.remove('btn-primary');
	document.getElementById('cam_top').classList.add('btn-secondary');
	document.getElementById('cam_bottom').classList.remove('btn-primary');
	document.getElementById('cam_bottom').classList.add('btn-secondary');
	document.getElementById('cam_left').classList.remove('btn-primary');
	document.getElementById('cam_left').classList.add('btn-secondary');
	document.getElementById('cam_right').classList.remove('btn-primary');
	document.getElementById('cam_right').classList.add('btn-secondary');
}

function cameraBack()
{
	document.getElementById('modelRec__BackCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__BackCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__BackCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__BackCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__BackCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__BackCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.remove('btn-primary');
	document.getElementById('cam_front').classList.add('btn-secondary');
	document.getElementById('cam_back').classList.add('btn-primary');
	document.getElementById('cam_back').classList.remove('btn-secondary');
	document.getElementById('cam_top').classList.remove('btn-primary');
	document.getElementById('cam_top').classList.add('btn-secondary');
	document.getElementById('cam_bottom').classList.remove('btn-primary');
	document.getElementById('cam_bottom').classList.add('btn-secondary');
	document.getElementById('cam_left').classList.remove('btn-primary');
	document.getElementById('cam_left').classList.add('btn-secondary');
	document.getElementById('cam_right').classList.remove('btn-primary');
	document.getElementById('cam_right').classList.add('btn-secondary');
}

function cameraLeft()
{
	document.getElementById('modelRec__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__LeftCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.remove('btn-primary');
	document.getElementById('cam_front').classList.add('btn-secondary');
	document.getElementById('cam_back').classList.remove('btn-primary');
	document.getElementById('cam_back').classList.add('btn-secondary');
	document.getElementById('cam_top').classList.remove('btn-primary');
	document.getElementById('cam_top').classList.add('btn-secondary');
	document.getElementById('cam_bottom').classList.remove('btn-primary');
	document.getElementById('cam_bottom').classList.add('btn-secondary');
	document.getElementById('cam_left').classList.add('btn-primary');
	document.getElementById('cam_left').classList.remove('btn-secondary');
	document.getElementById('cam_right').classList.remove('btn-primary');
	document.getElementById('cam_right').classList.add('btn-secondary');
}

function cameraRight()
{
	document.getElementById('modelRec__RightCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__RightCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__RightCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__RightCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__RightCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__RightCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.remove('btn-primary');
	document.getElementById('cam_front').classList.add('btn-secondary');
	document.getElementById('cam_back').classList.remove('btn-primary');
	document.getElementById('cam_back').classList.add('btn-secondary');
	document.getElementById('cam_top').classList.remove('btn-primary');
	document.getElementById('cam_top').classList.add('btn-secondary');
	document.getElementById('cam_bottom').classList.remove('btn-primary');
	document.getElementById('cam_bottom').classList.add('btn-secondary');
	document.getElementById('cam_left').classList.remove('btn-primary');
	document.getElementById('cam_left').classList.add('btn-secondary');
	document.getElementById('cam_right').classList.add('btn-primary');
	document.getElementById('cam_right').classList.remove('btn-secondary');
}

function cameraTop()
{
	document.getElementById('modelRec__TopCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__TopCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__TopCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__TopCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__TopCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__TopCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.remove('btn-primary');
	document.getElementById('cam_front').classList.add('btn-secondary');
	document.getElementById('cam_back').classList.remove('btn-primary');
	document.getElementById('cam_back').classList.add('btn-secondary');
	document.getElementById('cam_top').classList.add('btn-primary');
	document.getElementById('cam_top').classList.remove('btn-secondary');
	document.getElementById('cam_bottom').classList.remove('btn-primary');
	document.getElementById('cam_bottom').classList.add('btn-secondary');
	document.getElementById('cam_left').classList.remove('btn-primary');
	document.getElementById('cam_left').classList.add('btn-secondary');
	document.getElementById('cam_right').classList.remove('btn-primary');
	document.getElementById('cam_right').classList.add('btn-secondary');
}

function cameraBottom()
{
	document.getElementById('modelRec__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('modelBug__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('modelXy__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('modelHar__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('modelMar__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('modelCym__BottomCamera').setAttribute('bind', 'true');
	document.getElementById('cam_front').classList.remove('btn-primary');
	document.getElementById('cam_front').classList.add('btn-secondary');
	document.getElementById('cam_back').classList.remove('btn-primary');
	document.getElementById('cam_back').classList.add('btn-secondary');
	document.getElementById('cam_top').classList.remove('btn-primary');
	document.getElementById('cam_top').classList.add('btn-secondary');
	document.getElementById('cam_bottom').classList.add('btn-primary');
	document.getElementById('cam_bottom').classList.remove('btn-secondary');
	document.getElementById('cam_left').classList.remove('btn-primary');
	document.getElementById('cam_left').classList.add('btn-secondary');
	document.getElementById('cam_right').classList.remove('btn-primary');
	document.getElementById('cam_right').classList.add('btn-secondary');
}