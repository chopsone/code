// JavaScript Document
$(document).ready(function() {
	
	selectPage();
	selectModel();
	selectModelModifiers();

	function selectPage() {

		$('#home').show();
		$('#about').hide();
		$('#models').hide();
		$('#statement').hide();
		$('#references').hide();
		$('#deepund').hide();
		$('#files').hide();
		$('#recorderDescription').hide();
		$('#bugleDescription').hide(); 
		$('#xylophoneDescription').hide();
		$('#harmonicaDescription').hide();
		$('#maracasDescription').hide();
		$('#cymbalsDescription').hide();
		$('#overlayR').hide();
		$('#overlayB').hide();
		$('#overlayX').hide();
		$('#overlayH').hide();
		$('#overlayM').hide();
		$('#overlayC').hide();


		$('#navHome').click(function(){
			$('#home').show();
			$('#about').hide();
			$('#models').hide();
			$('#statement').hide();
			$('#references').hide();
			$('#deepund').hide();
			$('#files').hide();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navHome').classList.add('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navAbout').click(function(){
			$('#home').hide();
			$('#about').show();
			$('#models').hide();
			$('#statement').hide();
			$('#references').hide();
			$('#deepund').hide();
			$('#files').hide();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.add('active');
			document.getElementById('navModels').classList.remove('active'); 
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navModels').click(function(){
			$('#home').hide();
			$('#about').hide();
			$('#models').show();
			$('#statement').hide();
			$('#references').hide();
			$('#deepund').hide();
			$('#files').hide();
			$('#recorder').show();
			$('#bugle').hide();
			$('#xylophone').hide();
			$('#harmonica').hide();
			$('#maracas').hide();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').show();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.add('active');
			document.getElementById('navRecorder').classList.add('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.remove('active'); 
			document.getElementById('navMaracas').classList.remove('active'); 
			document.getElementById('navCymbals').classList.remove('active');
			play('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navContact').click(function(){
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navStatement').click(function(){
			$('#home').hide();
			$('#about').hide();
			$('#models').hide();
			$('#statement').show();
			$('#references').hide();
			$('#deepund').hide();
			$('#files').hide();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide(); 
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navReferences').click(function(){
			$('#home').hide();
			$('#about').hide();
			$('#models').hide();
			$('#statement').hide();
			$('#references').show();
			$('#deepund').hide();
			$('#files').hide();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide(); 
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navDeepUnd').click(function(){
			$('#home').hide();
			$('#about').hide();
			$('#models').hide();
			$('#statement').hide();
			$('#references').hide();
			$('#deepund').show();
			$('#files').hide();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide(); 
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navFiles').click(function(){
			$('#home').hide();
			$('#about').hide();
			$('#models').hide();
			$('#statement').hide();
			$('#references').hide();
			$('#deepund').hide();
			$('#files').show();
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide(); 
			document.getElementById('navHome').classList.remove('active');
			document.getElementById('navAbout').classList.remove('active');
			document.getElementById('navModels').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym'); 
			changeToOriginalColour();
			stopAnimation();
		});

		$('#recorderImage').hover(function() {
			$('#overlayR').show();
		});

		$('#recorderImage').click(function() {
			$('#overlayR').show();
		});

		$('#bugleImage').hover(function() {
			$('#overlayB').show();
		});

		$('#bugleImage').click(function() {
			$('#overlayB').show();
		});

		$('#xylophoneImage').hover(function() {
			$('#overlayX').show();
		});

		$('#xylophoneImage').click(function() {
			$('#overlayX').show();
		});

		$('#harmonicaImage').hover(function() {
			$('#overlayH').show();
		});

		$('#harmonicaImage').click(function() {
			$('#overlayH').show();
		});

		$('#maracasImage').hover(function() {
			$('#overlayM').show();
		});

		$('#maracasImage').click(function() {
			$('#overlayM').show();
		});

		$('#cymbalsImage').hover(function() {
			$('#overlayC').show();
		});

		$('#cymbalsImage').click(function() {
			$('#overlayC').show();
		});
	}

	function selectModel() {

		$('#navRecorder').click(function(){
			$('#recorder').show();
			$('#bugle').hide();
			$('#xylophone').hide();
			$('#harmonica').hide();
			$('#maracas').hide();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').show();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navRecorder').classList.add('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.remove('active'); 
			document.getElementById('navMaracas').classList.remove('active'); 
			document.getElementById('navCymbals').classList.remove('active');
			play('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym');
			document.getElementById('modelRec__mat1').setAttribute('diffuseColor', '1 0.7686 0.498');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navBugle').click(function(){
			$('#recorder').hide();
			$('#bugle').show();
			$('#xylophone').hide();
			$('#harmonica').hide();
			$('#maracas').hide();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').hide();
			$('#bugleDescription').show(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navRecorder').classList.remove('active');
			document.getElementById('navBugle').classList.add('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.remove('active');	
			document.getElementById('navMaracas').classList.remove('active');
			document.getElementById('navCymbals').classList.remove('active');	  
			stop('modelRec');
			play('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navXylophone').click(function(){
			$('#recorder').hide();
			$('#bugle').hide();
			$('#xylophone').show();
			$('#harmonica').hide();
			$('#maracas').hide();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').show();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navRecorder').classList.remove('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.add('active'); 
			document.getElementById('navHarmonica').classList.remove('active');  
			document.getElementById('navMaracas').classList.remove('active');  
			document.getElementById('navCymbals').classList.remove('active'); 
			stop('modelRec');
			stop('modelBug');
			play('modelXy');
			stop('modelHar');
			stop('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navHarmonica').click(function(){
			$('#recorder').hide();
			$('#bugle').hide();
			$('#xylophone').hide();
			$('#harmonica').show();
			$('#maracas').hide();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').show();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').hide();
			document.getElementById('navRecorder').classList.remove('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.add('active');   
			document.getElementById('navMaracas').classList.remove('active'); 
			document.getElementById('navCymbals').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			play('modelHar');
			stop('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navMaracas').click(function(){
			$('#recorder').hide();
			$('#bugle').hide();
			$('#xylophone').hide();
			$('#harmonica').hide();
			$('#maracas').show();
			$('#cymbals').hide();
			$('#interaction').show(); 
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').show();
			$('#cymbalsDescription').hide();
			document.getElementById('navRecorder').classList.remove('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.remove('active');   
			document.getElementById('navMaracas').classList.add('active'); 
			document.getElementById('navCymbals').classList.remove('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			play('modelMar');
			stop('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});

		$('#navCymbals').click(function(){
			$('#recorder').hide();
			$('#bugle').hide();
			$('#xylophone').hide();
			$('#harmonica').hide();
			$('#maracas').hide();
			$('#cymbals').show();
			$('#interaction').show(); 
			$('#recorderDescription').hide();
			$('#bugleDescription').hide(); 
			$('#xylophoneDescription').hide();
			$('#harmonicaDescription').hide();
			$('#maracasDescription').hide();
			$('#cymbalsDescription').show();
			document.getElementById('navRecorder').classList.remove('active');
			document.getElementById('navBugle').classList.remove('active');
			document.getElementById('navXylophone').classList.remove('active'); 
			document.getElementById('navHarmonica').classList.remove('active');   
			document.getElementById('navMaracas').classList.remove('active'); 
			document.getElementById('navCymbals').classList.add('active');
			stop('modelRec');
			stop('modelBug');
			stop('modelXy');
			stop('modelHar');
			stop('modelMar');
			play('modelCym');
			changeToOriginalColour();
			stopAnimation();
		});
	}

	function selectModelModifiers() {

		$('#cameraControls').show();
		$('#animationControls').hide();
		$('#renderControls').hide();
		$('#lightingControls').hide();
		document.getElementById('navCamControls').classList.add('active');
		document.getElementById('navAnimControls').classList.remove('active');
		document.getElementById('navRendControls').classList.remove('active'); 
		document.getElementById('navLightControls').classList.remove('active');   

		$('#navCamControls').click(function(){
			$('#cameraControls').show();
			$('#animationControls').hide();
			$('#renderControls').hide();
			$('#lightingControls').hide();
			document.getElementById('navCamControls').classList.add('active');
			document.getElementById('navAnimControls').classList.remove('active');
			document.getElementById('navRendControls').classList.remove('active'); 
			document.getElementById('navLightControls').classList.remove('active');   
		});

		$('#navAnimControls').click(function(){
			$('#cameraControls').hide();
			$('#animationControls').show();
			$('#renderControls').hide();
			$('#lightingControls').hide();
			document.getElementById('navCamControls').classList.remove('active');
			document.getElementById('navAnimControls').classList.add('active');
			document.getElementById('navRendControls').classList.remove('active'); 
			document.getElementById('navLightControls').classList.remove('active');   
		});

		$('#navRendControls').click(function(){
			$('#cameraControls').hide();
			$('#animationControls').hide();
			$('#renderControls').show();
			$('#lightingControls').hide();
			document.getElementById('navCamControls').classList.remove('active');
			document.getElementById('navAnimControls').classList.remove('active');
			document.getElementById('navRendControls').classList.add('active'); 
			document.getElementById('navLightControls').classList.remove('active');   
		});

		$('#navLightControls').click(function(){
			$('#cameraControls').hide();
			$('#animationControls').hide();
			$('#renderControls').hide();
			$('#lightingControls').show();
			document.getElementById('navCamControls').classList.remove('active');
			document.getElementById('navAnimControls').classList.remove('active');
			document.getElementById('navRendControls').classList.remove('active'); 
			document.getElementById('navLightControls').classList.add('active');   
		});
	}

});

function changeLook() {
	document.getElementById('bodyColor').style.backgroundColor = '#C6E7F3';
	document.getElementById('headerColor').style.backgroundColor = 'rgba(100, 100, 221, 1)';
	document.getElementById('footerColor').style.backgroundColor = '#E4FFFD';
}

function changeBack() {
	document.getElementById('bodyColor').style.backgroundColor = 'rgba(0, 2, 121, 1.0)';
	document.getElementById('headerColor').style.backgroundColor = '#E4FFFD';
	document.getElementById('footerColor').style.backgroundColor = '#C6E7F3';
}

